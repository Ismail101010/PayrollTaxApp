package com.example.payroll_calculator

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
